

## Usage

### Package
Ensure all required packages are install at root:
```
pip3 install requests bs4 -t .
```
Zip all files
```
zip -r package.zip *
```
Deploy to AWS:
```
serverless deploy
```
